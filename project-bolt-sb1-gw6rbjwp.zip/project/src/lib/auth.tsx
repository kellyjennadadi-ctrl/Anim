import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';

export interface Centre {
  id: string;
  name: string;
  pin_code: string;
  type?: string;
}

export interface UserProfile {
  full_name: string;
  role: string;
  email: string;
  phone: string | null;
  diploma: string | null;
  emergency_contact: string | null;
}

interface AuthState {
  session: import('@supabase/supabase-js').Session | null;
  profile: UserProfile | null;
  centres: Centre[];
  activeCentre: Centre | null;
  loading: boolean;
  isAuthenticated: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string, role: string) => Promise<{ error: string | null }>;
  localSignIn: (email: string) => void;
  signOut: () => Promise<void>;
  selectCentre: (centre: Centre, pinCode: string) => Promise<{ error: string | null }>;
  createCentre: (name: string, type: string, pinCode: string) => Promise<{ error: string | null; centre?: Centre }>;
  clearActiveCentre: () => void;
  refreshCentres: () => Promise<void>;
  updateProfile: (updates: Partial<Pick<UserProfile, 'phone' | 'diploma' | 'emergency_contact' | 'full_name' | 'role'>>) => Promise<{ error: string | null }>;
  demoSignIn: () => void;
}

const AuthContext = createContext<AuthState | null>(null);

const STORAGE_CENTRE = 'active-centre-id';

const DEFAULT_PROFILE: UserProfile = {
  full_name: 'Kelly Dadi',
  role: 'adjoint',
  email: 'kelly.dadi@outlook.fr',
  phone: null,
  diploma: null,
  emergency_contact: null,
};

const DEMO_CENTRES: Centre[] = [
  { id: 'demo-1', name: 'École Pablo Neruda', pin_code: '2026', type: 'Periscolaire' },
];

function safeGetItem(key: string): string | null {
  try { return localStorage.getItem(key); } catch { return null; }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<import('@supabase/supabase-js').Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(DEFAULT_PROFILE);
  const [centres, setCentres] = useState<Centre[]>(DEMO_CENTRES);
  const [activeCentre, setActiveCentre] = useState<Centre | null>(DEMO_CENTRES[0]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(true);

  const fetchProfile = useCallback(async (userId: string, email: string) => {
    try {
      const { data } = await supabase
        .from('user_profiles')
        .select('full_name, role, phone, diploma, emergency_contact')
        .eq('id', userId)
        .maybeSingle();
      if (data) {
        const d = data as { full_name: string; role: string; phone: string | null; diploma: string | null; emergency_contact: string | null };
        setProfile({
          full_name: d.full_name,
          role: d.role,
          email,
          phone: d.phone,
          diploma: d.diploma,
          emergency_contact: d.emergency_contact,
        });
      } else {
        setProfile({ full_name: email, role: 'animateur', email, phone: null, diploma: null, emergency_contact: null });
      }
    } catch {
      setProfile({ full_name: email, role: 'animateur', email, phone: null, diploma: null, emergency_contact: null });
    }
  }, []);

  const refreshCentres = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('centres')
        .select('id, name, pin_code, type')
        .order('name', { ascending: true });
      if (error || !data || data.length === 0) {
        setCentres(DEMO_CENTRES);
        return;
      }
      setCentres((data as Centre[]) || []);
    } catch {
      setCentres(DEMO_CENTRES);
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    // Check for a saved Supabase session (instant, no blocking)
    supabase.auth.getSession()
      .then(({ data: { session: s } }) => {
        if (!mounted) return;
        setSession(s);
        if (s) {
          setIsAuthenticated(true);
          fetchProfile(s.user.id, s.user.email || '');
          refreshCentres();
        }
        // If no session, keep default profile so app renders without crashing;
        // the user can interact and sign in from the login screen when they choose to.
        setLoading(false);
      })
      .catch(() => {
        if (!mounted) return;
        setSession(null);
        setLoading(false);
      });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => {
      if (!mounted) return;
      setSession(s);
      if (s) {
        setIsAuthenticated(true);
        fetchProfile(s.user.id, s.user.email || '');
        refreshCentres();
      } else {
        // Sign-out: clear auth state but keep a default profile so React doesn't crash
        setIsAuthenticated(false);
        setProfile(DEFAULT_PROFILE);
        setActiveCentre(null);
        setCentres([]);
      }
      setLoading(false);
    });

    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, [fetchProfile, refreshCentres]);

  // Restore active centre from localStorage when centres load
  useEffect(() => {
    if (centres.length > 0 && !activeCentre) {
      const savedId = safeGetItem(STORAGE_CENTRE);
      if (savedId) {
        const found = centres.find((c) => c.id === savedId);
        if (found) setActiveCentre(found);
      }
    }
  }, [centres, activeCentre]);

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      return { error: error?.message || null };
    } catch {
      return { error: 'Impossible de se connecter au serveur. Vérifiez votre connexion.' };
    }
  }, []);

  const signUp = useCallback(async (email: string, password: string, fullName: string, role: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) return { error: error.message };
      if (data.user) {
        const { error: profileErr } = await supabase
          .from('user_profiles')
          .insert({ id: data.user.id, email, full_name: fullName, role });
        if (profileErr) return { error: profileErr.message };

        const nameParts = fullName.trim().split(/\s+/);
        const firstName = nameParts[0] || email.split('@')[0];
        const lastName = nameParts.slice(1).join(' ') || '';
        const dbRole = role === 'directeur' ? 'Direction' : role === 'adjoint' ? 'Adjoint' : 'Permanent';
        const centreName = 'École Pablo Neruda';
        await supabase.from('animateurs').insert({
          centre_nom: centreName,
          first_name: firstName,
          last_name: lastName,
          role: dbRole,
          phone: '',
          diplomas: [],
          slots: [],
          present_today: false,
        });
      }
      return { error: null };
    } catch {
      return { error: 'Impossible de créer le compte. Vérifiez votre connexion.' };
    }
  }, []);

  const localSignIn = useCallback((email: string) => {
    const name = email.split('@')[0] || 'Utilisateur';
    const parts = name.split(/[._-]/);
    const full = parts.length >= 2
      ? parts.map((p) => p.charAt(0).toUpperCase() + p.slice(1)).join(' ')
      : name.charAt(0).toUpperCase() + name.slice(1);

    const firstName = parts.length >= 2 ? parts[0] : name;
    const lastName = parts.length >= 2 ? parts[parts.length - 1] : '';

    const isKellyDadi = email.toLowerCase().includes('kelly.dadi');
    const userRole = isKellyDadi ? 'adjoint' : 'directeur';

    const userSession = {
      id: 'dir-pablo',
      email,
      nom: lastName,
      prenom: firstName,
      role: userRole,
      centre: 'École Pablo Neruda',
    };
    try { localStorage.setItem('auth_user', JSON.stringify(userSession)); } catch { /* ignore */ }

    setIsAuthenticated(true);
    setProfile({
      full_name: full,
      role: userRole,
      email,
      phone: null,
      diploma: null,
      emergency_contact: null,
    });
    setCentres(DEMO_CENTRES);
    setActiveCentre(DEMO_CENTRES[0]);
    try { localStorage.setItem(STORAGE_CENTRE, DEMO_CENTRES[0].id); } catch { /* ignore */ }
    setLoading(false);

    supabase
      .from('animateurs')
      .select('id')
      .eq('centre_nom', 'École Pablo Neruda')
      .eq('first_name', firstName.charAt(0).toUpperCase() + firstName.slice(1))
      .eq('last_name', lastName.charAt(0).toUpperCase() + lastName.slice(1))
      .maybeSingle()
      .then(({ data }) => {
        if (!data) {
          const isAdjoint = email.toLowerCase().includes('kelly.dadi');
          supabase.from('animateurs').insert({
            centre_nom: 'École Pablo Neruda',
            first_name: firstName.charAt(0).toUpperCase() + firstName.slice(1),
            last_name: lastName.charAt(0).toUpperCase() + lastName.slice(1),
            role: isAdjoint ? 'Adjoint' : 'Direction',
            phone: '',
            diplomas: [],
            slots: [],
            present_today: false,
          }).then(() => { /* realtime will sync */ });
        }
      });
  }, []);

  const signOut = useCallback(async () => {
    try { localStorage.removeItem(STORAGE_CENTRE); } catch { /* ignore */ }
    setSession(null);
    setActiveCentre(null);
    setProfile(DEFAULT_PROFILE);
    setCentres([]);
    setIsAuthenticated(false);
    try { await supabase.auth.signOut(); } catch { /* ignore */ }
  }, []);

  const demoSignIn = useCallback(() => {
    setIsAuthenticated(true);
    setProfile({
      full_name: 'Utilisateur Démo',
      role: 'directeur',
      email: 'demo@accueil-loisirs.fr',
      phone: null,
      diploma: null,
      emergency_contact: null,
    });
    setCentres(DEMO_CENTRES);
    setLoading(false);
  }, []);

  const selectCentre = useCallback(async (centre: Centre, pinCode: string) => {
    try { localStorage.setItem(STORAGE_CENTRE, centre.id); } catch { /* ignore */ }
    setActiveCentre(centre);
    return { error: null };
  }, []);

  const clearActiveCentre = useCallback(() => {
    try { localStorage.removeItem(STORAGE_CENTRE); } catch { /* ignore */ }
    setActiveCentre(null);
  }, []);

  const createCentre = useCallback(async (name: string, type: string, pinCode: string) => {
    try {
      const { data, error } = await supabase
        .from('centres')
        .insert({ name, type, pin_code: pinCode })
        .select('id, name, pin_code, type')
        .single();
      if (error) return { error: error.message };
      const newCentre = data as Centre;
      setCentres((prev) => [...prev, newCentre].sort((a, b) => a.name.localeCompare(b.name)));
      return { error: null, centre: newCentre };
    } catch {
      return { error: 'Impossible de créer le centre. Vérifiez votre connexion.' };
    }
  }, []);

  const updateProfile = useCallback(async (updates: Partial<Pick<UserProfile, 'phone' | 'diploma' | 'emergency_contact' | 'full_name' | 'role'>>) => {
    if (!session?.user) return { error: 'Non connecté' };
    try {
      const { error } = await supabase
        .from('user_profiles')
        .update(updates)
        .eq('id', session.user.id);
      if (error) return { error: error.message };
      setProfile((prev) => prev ? { ...prev, ...updates } : prev);
      return { error: null };
    } catch {
      return { error: 'Impossible de mettre à jour le profil.' };
    }
  }, [session]);

  return (
    <AuthContext.Provider
      value={{
        session,
        profile,
        centres,
        activeCentre,
        loading,
        isAuthenticated,
        signIn,
        signUp,
        localSignIn,
        signOut,
        selectCentre,
        createCentre,
        clearActiveCentre,
        refreshCentres,
        updateProfile,
        demoSignIn,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
