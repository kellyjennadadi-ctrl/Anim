import { useState, useEffect, useCallback, Component, type ReactNode } from 'react';
import { BottomNav } from '@/components/BottomNav';
import { PlanningTab } from '@/tabs/PlanningTab';
import { PointageTab } from '@/tabs/PointageTab';
import { SanteTab } from '@/tabs/SanteTab';
import { AnimationTab } from '@/tabs/AnimationTab';
import { EspaceProTab } from '@/tabs/EspaceProTab';
import { useOfflineSync } from '@/lib/useOfflineSync';
import { Loader2, Wifi, WifiOff, RefreshCw, Check, AlertCircle, Heart, Mail, Lock, Eye, EyeOff, Building2, ChevronRight, ArrowLeft, Zap, UserPlus, User as UserIcon } from 'lucide-react';
import { AppHeader } from '@/components/ProfileMenu';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { CentreSelectionScreen } from '@/components/CentreSelectionScreen';
import { children as initialChildren, animators as initialAnimators, schoolClasses as initialClasses } from '@/data/mockData';
import type { TabKey, Child, Animator, SchoolClass, AppMode, TimeSlot } from '@/types';
import type { Centre } from '@/lib/auth';

const DEFAULT_CENTRE: Centre = {
  id: 'demo-1',
  name: 'École Pablo Neruda',
  pin_code: '2026',
  type: 'Periscolaire',
};

interface PointageRow {
  id: string;
  centre_nom: string;
  enfant_nom: string;
  statut: string;
  creneau: string;
  date_pointage: string;
  updated_at: string;
}

const slotToDb: Record<TimeSlot, string> = {
  matin: 'matin',
  midi: 'midi',
  soir: 'soir',
  mercredi: 'journee',
};

const dbToSlot: Record<string, TimeSlot> = {
  matin: 'matin',
  midi: 'midi',
  soir: 'soir',
  journee: 'mercredi',
};

function getToday(): string {
  return new Date().toISOString().split('T')[0];
}

function childFullName(c: Child): string {
  return c.firstName + ' ' + c.lastName;
}

const INLINE_CENTRES = [
  { id: 'demo-1', name: 'Ecole Pablo Neruda', pin_code: '2026', type: 'Periscolaire' },
];

function App() {
  const { isAuthenticated, activeCentre, loading, demoSignIn, selectCentre, signIn, signUp, localSignIn } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex flex-col items-center justify-center">
        <div className="w-16 h-16 rounded-3xl bg-white/15 flex items-center justify-center mb-3 shadow-lg">
          <Heart size={28} className="text-white animate-pulse" />
        </div>
        <Loader2 size={20} className="animate-spin text-blue-200" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <InlineLogin demoSignIn={demoSignIn} signIn={signIn} signUp={signUp} localSignIn={localSignIn} selectCentre={selectCentre} />;
  }

  if (!activeCentre) {
    return (
      <ErrorBoundary fallbackName="CentreSelection">
        <CentreSelectionScreen />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary fallbackName="Application" onReset={() => window.location.reload()}>
      <AppContent />
    </ErrorBoundary>
  );
}

type LoginMode = 'signin' | 'signup';
type AuthStep = 1 | 2;

const ROLES = [
  { value: 'animateur', label: 'Animateur/trice' },
  { value: 'adjoint', label: 'Adjoint(e)' },
  { value: 'directeur', label: 'Directeur/trice' },
] as const;

function InlineLogin({
  demoSignIn,
  signIn,
  signUp,
  localSignIn,
  selectCentre,
}: {
  demoSignIn: () => void;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string, role: string) => Promise<{ error: string | null }>;
  localSignIn: (email: string) => void;
  selectCentre: (centre: Centre, pinCode: string) => Promise<{ error: string | null }>;
}) {
  const [mode, setMode] = useState<LoginMode>('signin');
  const [step, setStep] = useState<AuthStep>(1);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<string>('animateur');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Step 2 state
  const [selectedCentre, setSelectedCentre] = useState<typeof INLINE_CENTRES[0] | null>(null);
  const [centrePin, setCentrePin] = useState('');
  const [centreError, setCentreError] = useState<string | null>(null);

  const handleSignIn = async (e?: { preventDefault: () => void }) => {
    if (e) e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    setSubmitting(true);
    setError(null);

    try {
      const { error: err } = await signIn(email.trim(), password);
      if (err) {
        // Network auth failed — fall back to local session so the app never crashes
        localSignIn(email.trim());
        setSubmitting(false);
        return;
      }
      setSubmitting(false);
      setStep(2);
    } catch {
      // Any unexpected error — fall back to local session
      try {
        localSignIn(email.trim());
      } catch {
        setError('Impossible de se connecter. Veuillez réessayer.');
      }
      setSubmitting(false);
    }
  };

  const handleSignUp = async (e?: { preventDefault: () => void }) => {
    if (e) e.preventDefault();
    if (!email.trim() || !password.trim() || !fullName.trim()) return;
    if (password.length < 6) {
      setError('Le mot de passe doit contenir au moins 6 caractères.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const { error: err } = await signUp(email.trim(), password, fullName.trim(), role);
      if (err) {
        setError(err);
        setSubmitting(false);
        return;
      }
      setSuccessMsg('Compte créé ! Vous pouvez maintenant vous connecter.');
      setMode('signin');
      setPassword('');
    } catch {
      setError('Impossible de créer le compte. Vérifiez votre connexion.');
    }
    setSubmitting(false);
  };

  const handleStep2 = () => {
    if (!selectedCentre || centrePin.length < 4) return;
    selectCentre(selectedCentre, selectedCentre.pin_code);
  };

  useEffect(() => {
    if (selectedCentre && centrePin.length === 4) {
      handleStep2();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [centrePin, selectedCentre]);

  const handleDirectAccess = () => {
    demoSignIn();
    selectCentre(INLINE_CENTRES[0], '2026');
  };

  const switchMode = (m: LoginMode) => {
    setMode(m);
    setError(null);
    setSuccessMsg(null);
  };

  return (
    <div className="min-h-screen bg-[#0F172A] flex flex-col items-center px-6 py-10 relative">
      {/* Direct access button — top right, discreet */}
      <button
        onClick={handleDirectAccess}
        className="absolute top-4 right-4 text-xs text-blue-300/60 hover:text-blue-200 font-medium flex items-center gap-1 active:scale-95 transition"
        type="button"
      >
        <Zap size={12} />
        Accès direct (dépannage)
      </button>

      {/* Header */}
      <div className="flex flex-col items-center mb-8 w-full max-w-sm">
        <div className="w-16 h-16 rounded-3xl bg-white/15 backdrop-blur-sm flex items-center justify-center mb-3 shadow-lg">
          <Heart size={32} className="text-white" />
        </div>
        <h1 className="text-xl font-bold text-white">Accueil Loisirs</h1>
        <p className="text-sm text-blue-200 mt-1 text-center">Gestion d'activités périscolaires</p>
      </div>

      {/* ─── Step 1: Sign in / Sign up ─── */}
      {step === 1 && (
        <form
          onSubmit={(e) => { e.preventDefault(); mode === 'signin' ? handleSignIn() : handleSignUp(); }}
          className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6 space-y-5"
        >
          {/* Mode toggle */}
          <div className="flex gap-2 p-1 bg-gray-100 rounded-xl">
            <button
              onClick={() => switchMode('signin')}
              className={'flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-bold transition ' +
                (mode === 'signin' ? 'bg-white text-[#2563EB] shadow-sm' : 'text-gray-400')}
              type="button"
            >
              <UserIcon size={14} />
              Connexion
            </button>
            <button
              onClick={() => switchMode('signup')}
              className={'flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-bold transition ' +
                (mode === 'signup' ? 'bg-white text-[#2563EB] shadow-sm' : 'text-gray-400')}
              type="button"
            >
              <UserPlus size={14} />
              Créer un compte
            </button>
          </div>

          {successMsg && (
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-xl p-3">
              <Check size={16} className="text-emerald-500 flex-shrink-0" />
              <p className="text-xs text-emerald-700">{successMsg}</p>
            </div>
          )}

          {/* Full name — sign-up only */}
          {mode === 'signup' && (
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase">Nom et prénom</label>
              <div className="relative mt-1">
                <UserIcon size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-300" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Marie Dupont"
                  className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-900 outline-none focus:ring-2 ring-blue-200"
                />
              </div>
            </div>
          )}

          <div>
            <label className="text-xs font-semibold text-gray-400 uppercase">Adresse e-mail</label>
            <div className="relative mt-1">
              <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-300" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="marie.dupont@centre.fr"
                className="w-full pl-10 pr-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-900 outline-none focus:ring-2 ring-blue-200"
                autoFocus
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-gray-400 uppercase">Mot de passe</label>
            <div className="relative mt-1">
              <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-300" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === 'signup' ? '6 caractères minimum' : '********'}
                className="w-full pl-10 pr-10 py-3 bg-gray-50 rounded-xl text-sm text-gray-900 outline-none focus:ring-2 ring-blue-200"
              />
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-300"
                type="button"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Role selector — sign-up only */}
          {mode === 'signup' && (
            <div>
              <label className="text-xs font-semibold text-gray-400 uppercase">Rôle</label>
              <div className="flex gap-2 mt-1">
                {ROLES.map((r) => (
                  <button
                    key={r.value}
                    onClick={() => setRole(r.value)}
                    className={'flex-1 py-2.5 rounded-xl text-xs font-bold transition ' +
                      (role === r.value ? 'bg-[#2563EB] text-white shadow-sm' : 'bg-gray-100 text-gray-500')}
                    type="button"
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 rounded-xl p-3">
              <AlertCircle size={16} className="text-rose-500 flex-shrink-0" />
              <p className="text-xs text-rose-600">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={submitting || !email.trim() || !password.trim() || (mode === 'signup' && !fullName.trim())}
            className="w-full py-3.5 bg-[#2563EB] text-white font-bold rounded-2xl active:scale-95 transition disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-blue-200"
          >
            {submitting ? <Loader2 size={18} className="animate-spin" /> :
              mode === 'signin' ? <ChevronRight size={18} /> : <UserPlus size={18} />}
            {submitting ? 'Veuillez patienter...' : mode === 'signin' ? 'Se connecter' : 'Créer mon compte'}
          </button>
        </form>
      )}

      {/* ─── Step 2: Centre selection + PIN ─── */}
      {step === 2 && (
        <div className="w-full max-w-sm space-y-3">
          <button
            onClick={() => { setStep(1); setCentrePin(''); setSelectedCentre(null); setCentreError(null); }}
            className="flex items-center gap-1.5 text-xs text-blue-200 font-medium mb-2"
            type="button"
          >
            <ArrowLeft size={12} />
            Retour
          </button>

          <p className="text-xs font-bold text-blue-200 uppercase tracking-wide">Choisissez votre centre</p>

          {INLINE_CENTRES.map((centre) => (
            <button
              key={centre.id}
              onClick={() => { setSelectedCentre(centre); setCentreError(null); setCentrePin(''); }}
              className={'w-full flex items-center gap-4 p-4 rounded-2xl shadow-lg active:scale-[0.98] transition text-left border-2 ' +
                (selectedCentre?.id === centre.id ? 'bg-white border-[#2563EB]' : 'bg-white border-transparent')}
              type="button"
            >
              <div className="w-12 h-12 rounded-2xl bg-blue-100 flex items-center justify-center flex-shrink-0">
                <Building2 size={22} className="text-[#2563EB]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-gray-900">{centre.name}</p>
                <p className="text-xs text-gray-400 mt-0.5">{centre.type} — Code requis</p>
              </div>
              <ChevronRight size={20} className="text-gray-300 flex-shrink-0" />
            </button>
          ))}

          {selectedCentre && (
            <div className="bg-white rounded-3xl shadow-2xl p-6 space-y-4 mt-4 animate-[fadeIn_0.2s_ease]">
              <div className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-2xl bg-blue-100 flex items-center justify-center mb-3">
                  <Building2 size={26} className="text-[#2563EB]" />
                </div>
                <p className="text-sm font-bold text-gray-900 text-center">{selectedCentre.name}</p>
                <p className="text-xs text-gray-400 mt-1">Saisissez le code d'accès du centre</p>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-400 uppercase flex items-center gap-1">
                  <Lock size={12} /> Code d'accès
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  value={centrePin}
                  onChange={(e) => setCentrePin(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="----"
                  className="w-full mt-1 px-4 py-3 bg-gray-50 rounded-xl text-center text-2xl tracking-[0.5em] font-bold text-gray-900 outline-none focus:ring-2 ring-blue-200"
                  onKeyDown={(e) => e.key === 'Enter' && handleStep2()}
                  autoFocus
                />
              </div>

              {centreError && (
                <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 rounded-xl p-3">
                  <AlertCircle size={16} className="text-rose-500 flex-shrink-0" />
                  <p className="text-xs text-rose-600">{centreError}</p>
                </div>
              )}

              <button
                onClick={handleStep2}
                disabled={centrePin.length < 4}
                className="w-full py-3.5 bg-[#2563EB] text-white font-bold rounded-2xl active:scale-95 transition disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-blue-200"
                type="button"
              >
                <ChevronRight size={18} />
                Entrer
              </button>

              <p className="text-center text-xs text-gray-300">Code de test : 2026</p>
            </div>
          )}

          {/* Fallback on step 2 as well */}
          <button
            onClick={handleDirectAccess}
            className="w-full mt-4 py-2.5 text-sm font-medium text-blue-200 flex items-center justify-center gap-1.5 active:scale-95 transition"
            type="button"
          >
            <Zap size={14} />
            Accès direct (dépannage)
          </button>
        </div>
      )}
    </div>
  );
}

function AppContent() {
  const { activeCentre, profile, isAuthenticated } = useAuth();
  const effectiveCentre = activeCentre || DEFAULT_CENTRE;
  const [activeTab, setActiveTab] = useState<TabKey>('aujourdhui');
  const [pointageSlot, setPointageSlot] = useState<TimeSlot>('midi');
  const [children, setChildren] = useState<Child[]>(initialChildren);
  const [_animators] = useState<Animator[]>(initialAnimators);
  const [classes, setClasses] = useState<SchoolClass[]>(initialClasses);
  const [appMode, setAppMode] = useState<AppMode>('peri');
  const { status: connStatus, pendingCount, syncing, queuePointage, syncPending } = useOfflineSync();

  // Apply a batch of pointage rows to children state
  const applyPointages = useCallback((rows: PointageRow[]) => {
    setChildren((prev) =>
      prev.map((child) => {
        const childName = childFullName(child);
        const updated = { ...child, present: { ...child.present } };
        for (const row of rows) {
          if (row.enfant_nom !== childName) continue;
          const slot = dbToSlot[row.creneau];
          if (!slot) continue;
          if (row.statut === 'present') {
            updated.present[slot] = true;
          } else if (row.statut === 'absent' || row.statut === 'parti') {
            updated.present[slot] = false;
          }
        }
        return updated;
      })
    );
  }, []);

  // Apply a single realtime pointage update
  const applySinglePointage = useCallback((row: PointageRow) => {
    setChildren((prev) =>
      prev.map((child) => {
        if (childFullName(child) !== row.enfant_nom) return child;
        const slot = dbToSlot[row.creneau];
        if (!slot) return child;
        const isPresent = row.statut === 'present';
        return {
          ...child,
          present: { ...child.present, [slot]: isPresent },
        };
      })
    );
  }, []);

  // ── Load pointages from Supabase and subscribe to realtime ──
  // Guard: only run when user is authenticated and profile exists
  useEffect(() => {
    if (!isAuthenticated || !profile || !activeCentre) return;

    const today = getToday();
    const centreNom = effectiveCentre.name;

    const loadPointages = async () => {
      const { data, error } = await supabase
        .from('pointages')
        .select('*')
        .eq('centre_nom', centreNom)
        .eq('date_pointage', today);

      if (error || !data) return;

      applyPointages(data as PointageRow[]);
    };

    loadPointages();

    const channel = supabase
      .channel('pointages-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'pointages',
          filter: 'centre_nom=eq.' + centreNom,
        },
        (payload) => {
          const row = payload.new as PointageRow;
          if (!row || row.date_pointage !== today) return;
          applySinglePointage(row);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [effectiveCentre, isAuthenticated, profile, activeCentre, applyPointages, applySinglePointage]);

  // ── Persist a pointage to Supabase (or queue if offline) ──
  const persistPointage = useCallback(
    async (child: Child, slot: TimeSlot, statut: string) => {
      if (!isAuthenticated || !profile) return;
      const dbSlot = slotToDb[slot];
      const today = getToday();

      const payload = {
        centre_nom: effectiveCentre.name,
        enfant_nom: childFullName(child),
        statut,
        creneau: dbSlot,
        date_pointage: today,
      };

      // Always queue locally first (acts as offline buffer)
      queuePointage(payload);

      // If online, try to sync immediately
      if (typeof navigator !== 'undefined' && navigator.onLine) {
        const { data: existing } = await supabase
          .from('pointages')
          .select('id')
          .eq('centre_nom', effectiveCentre.name)
          .eq('enfant_nom', childFullName(child))
          .eq('creneau', dbSlot)
          .eq('date_pointage', today)
          .maybeSingle();

        if (existing) {
          await supabase
            .from('pointages')
            .update({ statut, updated_at: new Date().toISOString() })
            .eq('id', (existing as { id: string }).id);
        } else {
          await supabase.from('pointages').insert(payload);
        }
      }
    },
    [effectiveCentre, queuePointage, isAuthenticated, profile]
  );

  const togglePresent = useCallback(
    (childId: string, slot: TimeSlot) => {
      let newPresent = false;
      setChildren((prev) =>
        prev.map((c) => {
          if (c.id !== childId) return c;
          newPresent = !c.present[slot];
          return { ...c, present: { ...c.present, [slot]: newPresent } };
        })
      );

      const child = children.find((c) => c.id === childId);
      if (child) {
        persistPointage(child, slot, newPresent ? 'present' : 'absent');
      }
    },
    [children, persistPointage]
  );

  const markDeparted = useCallback(
    (childId: string, slot: TimeSlot) => {
      setChildren((prev) =>
        prev.map((c) =>
          c.id === childId
            ? { ...c, present: { ...c.present, [slot]: false } }
            : c
        )
      );

      const child = children.find((c) => c.id === childId);
      if (child) {
        persistPointage(child, slot, 'parti');
      }
    },
    [children, persistPointage]
  );

  const markDepartedWithTime = useCallback(
    (childId: string, slot: TimeSlot, time: string) => {
      setChildren((prev) =>
        prev.map((c) =>
          c.id === childId
            ? { ...c, present: { ...c.present, [slot]: false }, departureTime: time }
            : c
        )
      );

      const child = children.find((c) => c.id === childId);
      if (child) {
        persistPointage(child, slot, 'parti');
      }
    },
    [children, persistPointage]
  );

  const renameClass = useCallback((classId: string, newName: string) => {
    setClasses((prev) =>
      prev.map((cl) => (cl.id === classId ? { ...cl, name: newName } : cl))
    );
    setChildren((prev) => {
      const cls = initialClasses.find((c) => c.id === classId);
      if (!cls) return prev;
      return prev.map((c) =>
        c.classe === cls.name ? { ...c, classe: newName } : c
      );
    });
  }, []);

  const addClass = useCallback((name: string, level: SchoolClass['level']) => {
    const newId = 'cl' + Date.now();
    setClasses((prev) => [...prev, { id: newId, name, level }]);
  }, []);

  const deleteClass = useCallback((classId: string) => {
    setClasses((prev) => prev.filter((cl) => cl.id !== classId));
  }, []);

  const addAbsence = useCallback((animatorId: string, date: string, slot: 'Midi' | 'Soir' | 'Journée', reason: string) => {
    void animatorId; void date; void slot; void reason;
  }, []);

  // Safety net: profile is guaranteed non-null via DEFAULT_PROFILE in auth context.
  // This guard only triggers if something truly unexpected happens — it won't crash.
  if (!profile) {
    return (
      <div className="min-h-screen bg-[#F1F5F9] flex flex-col items-center justify-center px-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-blue-100 flex items-center justify-center mb-4">
          <Heart size={28} className="text-[#2563EB]" />
        </div>
        <p className="text-sm font-bold text-[#1E293B] mb-1">Chargement...</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-3 px-5 py-2.5 bg-[#2563EB] text-white text-sm font-bold rounded-2xl active:scale-95 transition"
        >
          Recharger
        </button>
      </div>
    );
  }

  // ── Main app ──
  // Pointage is a full-screen overlay (not in bottom nav)
  if (activeTab === 'pointage') {
    return (
      <ErrorBoundary fallbackName="Pointage">
        <PointageTab children={children} onTogglePresent={togglePresent} onMarkDeparted={markDeparted} onMarkDepartedWithTime={markDepartedWithTime} classes={classes} mode={appMode} onModeChange={setAppMode} initialSlot={pointageSlot} onBack={() => setActiveTab('aujourdhui')} />
      </ErrorBoundary>
    );
  }

  return (
    <div className="max-w-lg mx-auto bg-[#F1F5F9] min-h-screen relative">
      {/* Offline / sync banner */}
      <OfflineBanner
        status={connStatus}
        pendingCount={pendingCount}
        syncing={syncing}
        onSync={syncPending}
      />
      <AppHeader onNavigateDirection={() => setActiveTab('espacepro')} centreName={effectiveCentre.name} />
      <div className="pt-2">
        {activeTab === 'aujourdhui' && <PlanningTab onNavigate={setActiveTab} children={children} mode={appMode} onModeChange={setAppMode} onOpenPointage={(slot: TimeSlot) => { setPointageSlot(slot); setActiveTab('pointage'); }} />}
        {activeTab === 'animation' && <AnimationTab />}
        {activeTab === 'sante' && <SanteTab />}
        {activeTab === 'espacepro' && (
          <EspaceProTab children={children} onChildrenChange={setChildren} centrePin={effectiveCentre.pin_code} />
        )}
      </div>
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

export default App;

function OfflineBanner({ status, pendingCount, syncing, onSync }: {
  status: 'online' | 'offline';
  pendingCount: number;
  syncing: boolean;
  onSync: () => void;
}) {
  if (status === 'online' && pendingCount === 0 && !syncing) {
    return (
      <div className="flex items-center justify-center gap-1.5 py-1 bg-emerald-50 border-b border-emerald-100">
        <Check size={11} className="text-emerald-500" />
        <span className="text-[10px] font-semibold text-emerald-600">Connecte / Synchronise</span>
      </div>
    );
  }

  if (status === 'offline') {
    return (
      <div className="flex items-center justify-center gap-1.5 py-1 bg-orange-50 border-b border-orange-100">
        <WifiOff size={11} className="text-orange-500" />
        <span className="text-[10px] font-semibold text-orange-600">
          Mode hors-ligne - Donnees enregistrees localement{pendingCount > 0 ? ' (' + pendingCount + ' en attente)' : ''}
        </span>
      </div>
    );
  }

  if (syncing || pendingCount > 0) {
    return (
      <button onClick={onSync} className="w-full flex items-center justify-center gap-1.5 py-1 bg-blue-50 border-b border-blue-100 active:scale-95 transition">
        <RefreshCw size={11} className={'text-blue-500 ' + (syncing ? 'animate-spin' : '')} />
        <span className="text-[10px] font-semibold text-blue-600">
          {syncing ? 'Synchronisation en cours...' : 'Synchroniser ' + pendingCount + ' pointage(s) en attente'}
        </span>
      </button>
    );
  }

  return null;
}

export function useNow(intervalMs: number = 30000): Date {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

class ErrorBoundary extends Component<{ children: ReactNode; fallbackName: string; onReset?: () => void }, { hasError: boolean; errorMessage: string; errorStack: string }> {
  state = { hasError: false, errorMessage: '', errorStack: '' };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, errorMessage: error.message, errorStack: error.stack || '' };
  }

  componentDidCatch(error: Error) {
    console.error('ErrorBoundary [' + this.props.fallbackName + ']:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F1F5F9] flex flex-col items-center justify-center px-6 py-8">
          <div className="w-16 h-16 rounded-3xl bg-rose-100 flex items-center justify-center mb-4">
            <AlertCircle size={28} className="text-rose-500" />
          </div>
          <p className="text-sm font-bold text-[#1E293B] mb-1">Erreur dans le module {this.props.fallbackName}</p>

          {/* Raw error message */}
          <div className="w-full max-w-lg mt-4 bg-rose-50 border border-rose-200 rounded-2xl p-4 overflow-hidden">
            <p className="text-xs font-bold text-rose-700 uppercase tracking-wide mb-2">Message d'erreur</p>
            <pre className="text-xs text-rose-900 font-mono whitespace-pre-wrap break-all">{this.state.errorMessage}</pre>
          </div>

          {/* Stack trace */}
          {this.state.errorStack && (
            <div className="w-full max-w-lg mt-3 bg-gray-900 border border-gray-700 rounded-2xl p-4 overflow-hidden">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-2">Stack trace</p>
              <pre className="text-[10px] text-gray-300 font-mono whitespace-pre-wrap break-all max-h-48 overflow-y-auto">{this.state.errorStack}</pre>
            </div>
          )}

          <button
            onClick={() => { this.setState({ hasError: false, errorMessage: '', errorStack: '' }); this.props.onReset?.(); }}
            className="mt-5 px-5 py-2.5 bg-[#2563EB] text-white text-sm font-bold rounded-2xl active:scale-95 transition"
          >
            Réessayer
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
