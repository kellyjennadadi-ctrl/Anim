import type { Child, Animator, CareRecord, MenuItem, SchoolClass } from '@/types';

export const centerName = 'École Pablo Neruda';

export const children: Child[] = [];

export const animators: Animator[] = [];

export const careRecords: CareRecord[] = [];

export const schoolClasses: SchoolClass[] = [];

export const menuItems: MenuItem[] = [];
